# MOTI AI — Android starter project

এটি MOTI AI-এর প্রথম Android starter project। এতে ডার্ক UI, Home / Explore / Profile navigation, Image-to-Video / Text-to-Video / Reference-to-Video entry points, image picker এবং prompt field আছে।

## শুধু Android ফোন দিয়ে APK বানানো

এই প্রজেক্টে `.github/workflows/build-apk.yml` যোগ করা আছে। GitHub Actions ব্যবহার করে ক্লাউডে APK build করা যাবে; নিজের ফোনে Android Studio লাগবে না।

1. GitHub-এ একটি নতুন **Private** repository তৈরি করো, নাম `moti-ai` রাখতে পারো।
2. ফোনে ZIP extract করে `MOTI_AI` ফোল্ডারের ভেতরের সব ফাইল ও `.github` ফোল্ডার repository-তে upload করো (root-এ `settings.gradle.kts` এবং `app/` থাকতে হবে)।
3. GitHub repository → **Actions** → **Build MOTI AI APK** → **Run workflow** চাপো।
4. Build শেষ হলে workflow run খুলে **Artifacts** থেকে `MOTI-AI-debug-APK` download করো।
5. ZIP extract করে `app-debug.apk` ফোনে install করো। Android চাইলে Settings থেকে ওই browser/file manager-এর **Install unknown apps** অনুমতি দিতে হবে।

## কী আছে / কী নেই

এটি UI starter, সম্পূর্ণ AI ভিডিও জেনারেটর নয়। Generate Video বোতাম বর্তমানে demo notice দেখায়। আসল ভিডিও তৈরি করতে আলাদা backend এবং video-generation model/API যুক্ত করতে হবে। API key কখনো APK-তে রাখা যাবে না; backend-এ রাখতে হবে।

Unlimited free AI video generation বাস্তবসম্মত নয়, কারণ ভিডিও মডেল চালাতে compute খরচ হয়। Free tier-এ দৈনিক সীমা/queue রাখা যেতে পারে।
