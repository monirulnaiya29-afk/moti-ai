package com.moti.ai

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF08080C)
private val Panel = Color(0xFF17182A)
private val Purple = Color(0xFF9657FF)
private val Muted = Color(0xFFAAA9B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MotiApp() }
    }
}

@Composable
fun MotiApp() {
    var tab by remember { mutableStateOf("Home") }
    var mode by remember { mutableStateOf<String?>(null) }
    var prompt by remember { mutableStateOf("") }
    var pickedImage by remember { mutableStateOf<Uri?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { pickedImage = it }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (mode != null) {
                CreateScreen(
                    mode = mode!!,
                    prompt = prompt,
                    onPrompt = { prompt = it },
                    pickedImage = pickedImage,
                    onPick = { picker.launch("image/*") },
                    onBack = { mode = null },
                    onGenerate = { notice = "MOTI AI UI প্রস্তুত! আসল AI ভিডিও তৈরি চালু করতে একটি video-generation backend/API যুক্ত করতে হবে।" }
                )
            } else {
                Scaffold(
                    containerColor = Bg,
                    bottomBar = {
                        NavigationBar(containerColor = Bg, contentColor = Color.White) {
                            listOf("Home", "Explore", "Profile").forEach { item ->
                                NavigationBarItem(
                                    selected = tab == item,
                                    onClick = { tab = item },
                                    icon = { Icon(when (item) { "Home" -> Icons.Default.Home; "Explore" -> Icons.Default.Explore; else -> Icons.Default.Person }, null) },
                                    label = { Text(item) },
                                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Color.White, indicatorColor = Panel, unselectedIconColor = Muted, unselectedTextColor = Muted)
                                )
                            }
                        }
                    }
                ) { padding ->
                    when (tab) {
                        "Home" -> HomeScreen(Modifier.padding(padding), onMode = { mode = it })
                        "Explore" -> SimplePage("Explore", "নতুন AI effects ও ভিডিও স্টাইল এখানে যোগ হবে।", Modifier.padding(padding))
                        else -> SimplePage("Profile", "MOTI AI-তে স্বাগতম!\n\nVersion 1.0 · Free interface", Modifier.padding(padding))
                    }
                }
            }
            notice?.let { msg ->
                AlertDialog(onDismissRequest = { notice = null }, confirmButton = { TextButton2("ঠিক আছে") { notice = null } }, title = { Text("MOTI AI") }, text = { Text(msg) }, containerColor = Panel)
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, onMode: (String) -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("MOTI AI ✨", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Surface(color = Purple, shape = RoundedCornerShape(30.dp)) { Text("◆ FREE", Modifier.padding(horizontal = 15.dp, vertical = 8.dp), color = Color.White, fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(25.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ModeCard("▣", "Image to\nVideo") { onMode("Image to Video") }
            ModeCard("✦", "Text to\nVideo") { onMode("Text to Video") }
            ModeCard("◉", "Reference to\nVideo") { onMode("Reference to Video") }
        }
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Chip("▣  All Effects", true)
            Chip("ϟ  New", false)
            Chip("☻  Trending", false)
        }
        Spacer(Modifier.height(28.dp))
        SectionTitle("Trending", "More  ›")
        val trending = listOf("Night Birthday", "Horse Leap", "Circle Flow", "Desert Calm", "Cola Tune", "Cruising On")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(trending) { EffectCard(it) { onMode("Text to Video") } } }
        Spacer(Modifier.height(26.dp))
        SectionTitle("Play in Style", "More  ›")
        val styles = listOf("Pet Moments", "Magic Portal", "Cinematic Night")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(styles) { EffectCard(it) { onMode("Text to Video") } } }
        Spacer(Modifier.height(18.dp))
        Text("শুরু করতে উপরের যেকোনো একটি AI tool বেছে নাও।", color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun ModeCard(symbol: String, label: String, onClick: () -> Unit) {
    Column(Modifier.weight(1f).height(142.dp).background(Panel, RoundedCornerShape(22.dp)).clickable { onClick() }.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Text(symbol, color = Purple, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 19.sp)
    }
}

@Composable
fun Chip(text: String, selected: Boolean) {
    Surface(color = if (selected) Color.White else Color(0xFF303034), shape = RoundedCornerShape(30.dp)) {
        Text(text, Modifier.padding(horizontal = 13.dp, vertical = 11.dp), color = if (selected) Color.Black else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SectionTitle(title: String, action: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text(action, color = Color.White, fontSize = 14.sp)
    }
    Spacer(Modifier.height(13.dp))
}

@Composable
fun EffectCard(name: String, onClick: () -> Unit) {
    Column(Modifier.width(154.dp).clickable { onClick() }) {
        Box(Modifier.fillMaxWidth().height(174.dp).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.AutoAwesome, null, tint = Purple, modifier = Modifier.size(42.dp))
        }
        Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 5.dp, top = 7.dp))
    }
}

@Composable
fun CreateScreen(mode: String, prompt: String, onPrompt: (String) -> Unit, pickedImage: Uri?, onPick: () -> Unit, onBack: () -> Unit, onGenerate: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text(mode, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(22.dp))
        if (mode != "Text to Video") {
            Surface(Modifier.fillMaxWidth().height(190.dp).clickable { onPick() }, color = Panel, shape = RoundedCornerShape(20.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(if (pickedImage == null) Icons.Default.AddPhotoAlternate else Icons.Default.CheckCircle, null, tint = Purple, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(10.dp))
                    Text(if (pickedImage == null) "ছবি নির্বাচন করতে চাপ দাও" else "ছবি নির্বাচন করা হয়েছে", color = Color.White)
                    Text("JPG / PNG", color = Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(20.dp))
        }
        Text("তোমার ভিডিওর বর্ণনা", color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = prompt, onValueChange = onPrompt, modifier = Modifier.fillMaxWidth(), minLines = 4, placeholder = { Text("যেমন: cinematic slow motion, golden sunset, realistic...") }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Purple, unfocusedBorderColor = Muted, focusedContainerColor = Panel, unfocusedContainerColor = Panel))
        Spacer(Modifier.height(18.dp))
        Text("ভিডিও সেটিংস", color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Chip("5 seconds", true); Chip("720p", false); Chip("9:16", false) }
        Spacer(Modifier.height(28.dp))
        Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple), shape = RoundedCornerShape(16.dp)) {
            Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Generate Video", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Text("নোট: এই প্রথম সংস্করণে অ্যাপের UI ও ছবি নির্বাচন কাজ করে। বাস্তব AI ভিডিও তৈরির জন্য নিরাপদ backend/API সংযোগ পরের ধাপে যুক্ত করতে হবে।", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
fun SimplePage(title: String, description: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.AutoAwesome, null, tint = Purple, modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(15.dp))
        Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(description, color = Muted, textAlign = TextAlign.Center)
    }
}

@Composable
fun TextButton2(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Text(label, color = Purple) }
}
